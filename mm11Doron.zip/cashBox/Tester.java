/*
 * Name: Doron Sharaby
 * Id: 204862197
 *date: 13/3/2021
 * */
/**/
import java.util.*;

public class Tester {

	public static void main(String[] args) {
		Item list[ ]= new Item[10];
		list[0]=new Item("banana",3);
		list[1]=new Item("wine",35);
		list[2]=new Item("coffee",30);
		list[3]=new Item("cream",7);
		list[4]=new Item("cola",10);
		list[5]=new Item("water",9);
		list[6]=new Item("steak",100);
		list[7]=new Item("apple",2);
		list[8]=new Item("milk",6);
		list[9]=new Item("eggs",13);


		CashBox newCB =new CashBox(200);


		System.out.println("hello welcome to our store, please choose one of the following task.");
		int a=100;
		while(a!=0) {
			Scanner sc= new Scanner(System.in);
			System.out.println("click :0-exit; 1 - to add an item; 2 - to print cart; 3- print total bill; 4-insert payment; 5- print cash in cash box.");
			a= sc.nextInt();
			switch (a) {
			case 0://exit
				break;
			case 1://add an item

				Scanner x= new Scanner(System.in);
				System.out.println("please enter the name of the item");
				String name = x.nextLine();

				Scanner y= new Scanner(System.in);
				System.out.println("please enter the amount of the item");
				int amount= y.nextInt();

				for(int i=0; i<list.length;i++) {
					String temp= list[i].getName();
					if(temp.equals(name))
					{
						newCB.addItem(amount, list[i]);
						break;
					}
				}

				break;

			case 2://print cart
				System.out.println("the cart is:");
				newCB.printCart();
				break;

			case 3://total bill
				System.out.format("the total bill: %d %n", newCB.getTotalBill());
				break;

			case 4:	//insert payment
				Scanner p= new Scanner(System.in);
				System.out.println("please enter the payment");
				int payment= p.nextInt();
				System.out.println("invoice data:");
				newCB.printCart();
				System.out.format("the total bill: %d %n", newCB.getTotalBill());
				System.out.println("the change:"+newCB.handlePayment(payment,newCB.getTotalBill()));
				
				break;

			case 5://print cash in Cash Box

				newCB.currentCash();
				break;

			}
		}
	}


}
