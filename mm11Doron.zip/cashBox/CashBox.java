/*
 * Cash Box by Doron Sharaby
 * ID : 204862197
 * Date: 14/3/2021
 * */

public class CashBox {
	private Row cart[]= new Row[100];
	private int cash;
	private int totalBill; 
	private int indexCart;

	public CashBox(int curCash) {
		cash=curCash;
		indexCart=0;
		totalBill=0;
	}


	//add an item to the cart
	public void addItem(int amount, Item item) {

		cart[indexCart] = new Row(amount, item);
		indexCart++;

	}

	//print the cart invoice 
	public void printCart() {
		totalBill=0;
		System.out.println("item	|	amount	|	total cost");
		for(int i=indexCart; i>=0;i--) {
			if(cart[i]!=null) {
				totalBill+=cart[i].getSumPayment();
				System.out.format("%s	|	%d	|	%d%n",cart[i].getItem().getName(),cart[i].getAmount(),cart[i].getSumPayment());
			}
		}
	}


	public int handlePayment(int payment, int sumInvoice) {
		int change = payment-sumInvoice;
		cash+=sumInvoice;
		for(int i=indexCart; i>=0;i--) {
			cart[i]=null;
		}
		totalBill=0;
		indexCart=0;
		return change;
	}

	public void currentCash(){
		System.out.format("the total cash in cash box: %d%n",cash);
	}

	public int getTotalBill(){

		return totalBill;
	}

}
