public class Item {

	private String name; 
	private int cost;

	Item(String curName, int curCost){
		name=curName;
		cost=curCost;

	}
	public String getName() {
		return name;
	}
	public int getCost() {
		return cost;
	}
}
