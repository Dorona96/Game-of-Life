public class Row {
	private int amount; 
	private Item item;
	private int sumPayment; 

	public Row(int curAmount, Item curItem) {
		amount=curAmount;
		item=curItem; 	
		sumPayment= amount*curItem.getCost();
	}
	public Item getItem() {
		return item;
	}
	public int getAmount() {
		return amount;
	}
	public int getSumPayment() {
		return sumPayment;
	}

}
